use petshop;

insert into tb_func (nome_func,endereco_func,salario,cargo,dt_admis,dt_nasc_func,gen_func,contato_func,email_func) values
("Théo","Caixa D'Água",3500.00,"Veterinário",'2022-10-19','2003-12-26','Masculino',"(71)99117-5007","theo.santana@ba.estudante.senai.br"),
("Isabel","Pituba",4000.00,"Veterinária",'2022-10-19','2005-06-07','Feminino',"(71)99121-4094","isabel.neves@ba.estudante.senai.br"),
("Ariadne","Dom Avelar",4500.00,"Veterinária",'2022-10-19','2003-03-14','Feminino',"(71)98652-6011","ariadne.alves@ba.estudante.senai.br"),
("Melanie","não sei",5000.00,"Veterinária",'2022-10-19','2004-05-17','Feminino',"(71)98773-0578","melanie.silva@ba.estudante.senai.br"),
("Diego","Castelo Branco",3550.00,"Veterinário",'2022-10-19','2003-04-19','Masculino',"(71)99713-5696","diego.perpetuo@ba.estudante.senai.br");

select * from tb_func;
drop table tb_func;
set foreign_key_checks = 0;
set foreign_key_checks = 1;

insert into tb_cliente (nome_cliente,email_cliente,endereco_cliente,dt_nasc_cliente,gen_cliente,contato_cliente) values
("Valdo","valdo.bras@ba.estudante.senai.br","Imbuí",'2003-06-23','Masculino',"(71)99709-9001"),
("Murilo","murilo.sergio@ba.estudante.senai.br","Mussurunga",'2003-08-09','Masculino',"(71)99703-0860"),
("Robinho","robinho.santos@ba.estudante.senai.br","Cajazeiras",'2003-06-23','Masculino',"(71)98875-1163"),
("Guilherme","guilherme.ribeiro@ba.estudante.senai.br","Itapuã",'2003-02-15','Masculino',"(71)99625-9427"),
("Gabriel","gabriel.teles@ba.estudante.senai.br","Pituba",'2003-06-23','Masculino',"(71)98697-1642");

select * from tb_cliente;

insert into tb_fornecedor (cnpj_forn,nome_forn,email_forn,contato_forn,ender_forn) values
("00.112.112/0001-22","Pedigreen","pedigreen@gmail.com","(71)99113-6789","Lauro de Freitas"),
("01.243.672/0001-25","Whisken","whisken@gmail.com","(71)98756-9311","Imbuí"),
("00.996.122/0001-29","Top Golden","topgolden@gmail.com","(71)99637-8824","Mussurunga"),
("00.189.111/0001-64","Fish Prises","fishprises@gmail.com","(71)9123-4233","Sussuarana"),
("00.265.587/0001-55","Chicken Dogs","chickendogs@gmail.com","(71)94238-4752","Baixa de Quintas");

select * from tb_fornecedor;

insert into tb_animal (nome_animal,raca,tipo_animal,porte,castrado,idade_animal,gen_animal,id_cliente) values
("Pretinha","SRD","Gato","Pequeno","Sim",1,"Fêmea",3),
("Branquinha","SRD","Gato","Pequeno","Sim",1,"Fêmea",3),
("Nino","SRD","Gato","Pequeno","Sim",1,"Macho",3),
("Leo","Bulldog francês","Cachorro","Médio","Não",2,"Macho",1),
("Layla","Sphynx","Gato","Pequeno","Sim",2,"Fêmea",2),
("Inu","Akita","Cachorro","Médio","Sim",6,"Macho",1);

select * from tb_animal;

insert into tb_servico (nome_serv,tipo_serv,valor_serv,dt_hr_serv,id_animal,id_cliente,id_func) values
("Higiene","Banho",80.00,'2022-11-01 16:00:00',4,1,1),
("Higiene","Banho",80.00,'2022-10-25 14:30:00',1,3,2),
("Clínico","Vacina",50.00,'2022-10-26 11:20:00',2,3,3),
("Clínico","Exame",65.00,'2022-12-11 17:40:00',3,3,1);

select * from tb_servico;

insert into tb_produto(cod_prod,nome_prod,valor_custo,valor_venda,marca_prod,funcional,dt_fbr,dt_val,qtd_mn,qtd_est,cnpj_forn) values
(1,"Ração",30.00,55,"Pedigreen","Alimentação",'2022-10-20','2023-10-20',50,60,"00.112.112/0001-22"),
(2,"Shampoo",20.00,35,"Top Golden","Higiene",'2022-10-20','2023-10-20',50,60,"00.996.122/0001-29"),
(3,"Ração",30.00,55,"Whisken","Alimentação",'2022-10-20','2023-10-20',50,60,"01.243.672/0001-25"),
(4,"Patê",10.00,20,"Fish Prises","Alimentação",'2022-10-20','2023-10-20',50,60,"00.189.111/0001-64"),
(5,"Perfume",30.00,35,"Chicken Dogs","Higiene",'2022-10-20','2023-10-20',50,60,"00.265.587/0001-55");

select * from tb_produto;

insert into tb_iv(qtd_vendida,cod_prod) values
(5,1),
(8,2),
(10,3);

select * from tb_iv;
drop table tb_iv;
set foreign_key_checks = 1;

insert into tb_venda(dt_hr_venda,desconto,valor_total,id_itens_venda,id_func) values
('2022-10-20 16:03:22',0,275.00,1,1),
('2022-10-25 12:30:14',0,280.00,2,1),
('2022-11-30 17:20:10',0,350.00,3,4);

select * from tb_venda;
drop table tb_venda;