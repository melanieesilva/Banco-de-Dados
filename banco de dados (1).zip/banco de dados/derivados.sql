use petshop;

#Consultas

#mostrar nome dos funcionários em ordem
select * from tb_func order by nome_func asc;

#mostrar os salários dos funcionários em ordem
select * from tb_func order by salario desc;

#mostrar nome dos animais em ordem
select * from tb_animal order by nome_animal asc;

#contar os gêneros dos animais
select gen_animal, count(gen_animal) as total from tb_animal group by tb_animal.gen_animal order by total;

#contar quantos clientes tem por bairro
select endereco_cliente, count(endereco_cliente) as total from tb_cliente group by tb_cliente.endereco_cliente order by total asc;

#contar quantos animais tem cada cliente
select id_cliente, count(id_cliente) as total from tb_animal group by tb_animal.id_cliente order by total asc;

#contar as idades dos animais
select idade_animal, count(*) as total from tb_animal group by idade_animal having count(*) > 0 order by total desc;

#mostrar os animais de um determinado cliente
select * from tb_animal where id_cliente = 1;

#contar quantos produtos tem de cada tipo/nome
select nome_prod, count(nome_prod) as total from tb_produto group by tb_produto.nome_prod order by total asc;

#------------------------------------------------------------------------------------------------------------------------------------------------------

#Inner Joins

#relacionar os clientes com seus animais
select tb_cliente.nome_cliente, tb_animal.nome_animal
from tb_cliente inner join tb_animal on tb_cliente.id_cliente = tb_animal.id_cliente;

#relacionar os fornecedores com os produtos fornecidos
select tb_fornecedor.nome_forn, tb_fornecedor.contato_forn, tb_produto.nome_prod, tb_produto.valor_custo
from tb_fornecedor inner join tb_produto on tb_fornecedor.cnpj_forn = tb_produto.cnpj_forn;

#relacionar os serviços com os funcionários que o fizeram
select nome_serv, tipo_serv, valor_serv, dt_hr_serv, nome_func
from tb_servico left join tb_func on tb_servico.id_func = tb_func.id_func;

#trigger para controle de estoque
DELIMITER $
create trigger Tgr_ItensVenda_Insert after insert
on tb_iv
for each row
begin
	update tb_produto set qtd_est = qtd_est - new.qtd_vendida
where cod_prod = new.cod_prod;
end$

create trigger Tgr_ItensVenda_Delete after delete
on tb_iv
for each row
begin
	update tb_produto set qtd_est = qtd_est + old.qtd_vendida
where cod_prod = old.cod_prod;
end$

DELIMITER ;

#Procedures
DELIMITER $$
create procedure pesquisar_animal(in idbusca int)
begin
select nome_animal, tipo_animal, raca, id_cliente
from tb_animal
where id_animal = idbusca;
end $$
DELIMITER ;

DELIMITER $$
create procedure pesquisar_funcionario(in idbusca int)
begin
select nome_func, cargo, salario, id_func
from tb_func
where id_func = idbusca;
end $$
DELIMITER ;

DELIMITER $$
create procedure pesquisar_cliente(in idbusca int)
begin
select nome_cliente, endereco_cliente, contato_cliente, id_cliente
from tb_cliente
where id_cliente = idbusca;
end $$
DELIMITER ;

DELIMITER $$
create procedure selecionar_produto(in quantidade int)
begin
select *from tb_produto
limit quantidade;
end $$
DELIMITER ;

DELIMITER $$
create procedure verificar_qtd_produto(out quantidade int)
begin
select count(*) into quantidade from tb_produto;
end $$
DELIMITER ;

#Calls
call pesquisar_animal(2);
call pesquisar_cliente(2);
call pesquisar_funcionario(3);
call selecionar_produto(3);
call verificar_qtd_produto(@total);
select @total;

#Views
create view v as select qtd_vendida, valor_venda, qtd_vendida*valor_venda as Total from tb_iv, tb_produto;
select * from v;