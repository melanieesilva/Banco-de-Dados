create database petshop;
use petshop;

create table tb_func(
	id_func int not null auto_increment primary key,
    nome_func varchar(30) not null,
    endereco_func varchar(50) not null,
    salario real not null,
    cargo varchar(20) not null,
    dt_admis date not null,
    dt_nasc_func date not null,
    gen_func enum ('Masculino', 'Feminino'),
    contato_func varchar(20) not null,
    email_func varchar(50) not null
);

create table tb_cliente(
	id_cliente int not null auto_increment primary key,
    nome_cliente varchar(30) not null,
    email_cliente varchar(50) not null,
    endereco_cliente varchar(50) not null,
    dt_nasc_cliente date not null,
    gen_cliente enum ('Masculino', 'Feminino'),
    contato_cliente varchar(20) not null
);

create table tb_fornecedor(
	cnpj_forn varchar(20) not null primary key,
    nome_forn varchar (30) not null,
    email_forn varchar(50) not null,
    contato_forn varchar(20) not null,
    ender_forn varchar(50) not null
);

create table tb_animal(
	id_animal int not null auto_increment primary key,
    nome_animal varchar(30) not null,
    raca varchar(20) not null,
    tipo_animal varchar(20) not null,
    porte enum ('Pequeno','Médio','Grande') not null,
    castrado enum ('Sim','Não') not null,
    idade_animal int not null,
    gen_animal varchar(20) not null,
    
    id_cliente int not null,
    foreign key (id_cliente) references tb_cliente (id_cliente)
);

create table tb_servico(
	id_serv int not null auto_increment primary key,
    nome_serv varchar(30) not null,
    tipo_serv varchar(30) not null,
    valor_serv real not null,
    dt_hr_serv datetime,
    
    id_animal int not null,
    id_cliente int not null,
    id_func int not null,
    
    foreign key (id_animal) references tb_animal (id_animal),
	foreign key (id_cliente) references tb_cliente (id_cliente),
	foreign key (id_func) references tb_func (id_func)
);

create table tb_produto(
	cod_prod int not null primary key,
	nome_prod varchar(30) not null,
	valor_custo real not null,
	valor_venda real not null,
	marca_prod varchar(30) not null,
	funcional varchar(30) not null,
	dt_fbr date not null,
	dt_val date not null,
	qtd_mn int not null,
	qtd_est int not null,

	cnpj_forn varchar(20) not null,
	foreign key (cnpj_forn) references tb_fornecedor (cnpj_forn)
);

create table tb_iv(
	id_itens_venda int not null auto_increment primary key,
	qtd_vendida int not null,

	cod_prod int not null,
	foreign key (cod_prod) references tb_produto (cod_prod)
);

create table tb_venda(
	cod_venda int not null auto_increment primary key,
    dt_hr_venda datetime not null,
    desconto real not null,
    valor_total real not null,
    
    id_itens_venda int not null,
    id_func int not null,
    foreign key (id_itens_venda) references tb_iv (id_itens_venda),
    foreign key (id_func) references tb_func (id_func)
);

select * from tb_func;
select * from tb_cliente;
select * from tb_fornecedor;
select * from tb_animal;
select * from tb_servico;
select * from tb_produto;
select * from tb_iv;
select * from tb_venda;
SET foreign_key_checks = 1;

SET foreign_key_checks = 0;
DROP TABLE tb_func;
DROP TABLE tb_cliente;
DROP TABLE tb_fornecedor;
DROP TABLE tb_animal;
DROP TABLE tb_servico;
DROP TABLE tb_produto;
DROP TABLE tb_iv;
DROP TABLE tb_venda;