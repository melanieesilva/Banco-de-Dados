create database PetShop;
USE PetShop;

CREATE TABLE Funcionarios(

Nome varchar(30) not null,
id_func int not null primary key  auto_increment,
Telefone1 int not null,
Email varchar (30),
Salario float,
EstadoCivil varchar(20) default 'Solteiro',
sexo enum('F','M')
);

CREATE TABLE Setor(
NomeSetor varchar (30),
idSetor int primary key,
Pets enum('SIM','NÃO') 

);

CREATE TABLE Agendamento(
Nome varchar (30),
Telefone1 varchar (11),
Telefone2 varchar(11),
CPF varchar(15) primary key,
EnderecoEntregaDoPet varchar(50),
NomePet varchar(50),
DataAtend date,
HorarioAtend time
);

CREATE TABLE Servicos(
TipoServico varchar(25),
ValorServico float,
TempoServico datetime
);

CREATE TABLE FormaPag(
FormaPagamento enum ('Crédito','Débito','A vista')

);

CREATE TABLE Cliente(
Nome varchar(30),
CPFDono varchar(15) primary key,
Telefone1 varchar (11),
Telefone2 varchar (11),
Endereco varchar (50)
);

CREATE TABLE Pet(
NomePet varchar (30),
Raca varchar (20),
CPFDono varchar (15), 
foreign key (CPFDono) references Cliente (CPFDono)

);

CREATE TABLE Fornecedores(
Nome varchar(30),
Telefone1 varchar(11),
Telefone2 varchar(11),
CPF varchar(15),
EnderecoEntrega varchar(50),
Cod_Pedido int,
DataEntrega date


);

CREATE TABLE Produtos(
NomeProd varchar(30),
Cod_Produto int(3) primary key,
ValorProd float,
QtdEstocada int,
FormaPag enum('Crédito','Débito','A vista')
);

